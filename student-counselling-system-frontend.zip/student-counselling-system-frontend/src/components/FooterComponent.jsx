import React from 'react';

function FooterComponent() {
  return (
    <footer className="bg-light text-dark py-3 mt-auto border-top">
      <div className="container text-center">
        <small>
          &copy; {new Date().getFullYear()} Student Counselling Appointment System. Built with 💙 for students.
        </small>
      </div>
    </footer>
  );
}

export default FooterComponent;

// src/components/LoginComponent.jsx
import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthService from '../services/AuthService';
import { AuthContext } from '../context/AuthContext';

function LoginComponent() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login: contextLogin } = useContext(AuthContext); // use context login

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      console.log("🔐 Submitting credentials:", { username, password });
      await AuthService.login({ username, password });

      const token = AuthService.getToken();
      const role = AuthService.getUserRole();

      // ✅ Store role in localStorage so TokenUtils can attach it later
      AuthService.setUserRole(role);

      console.log("✅ Login successful");
      console.log("🪪 Stored token:", token);
      console.log("👤 Stored role:", role);

      if (!role) {
        console.warn("⚠️ Role is undefined or missing from token/localStorage");
        setError("Login succeeded, but role is missing. Cannot redirect.");
        return;
      }

      // ✅ Update context after login so PrivateRoute detects it
      contextLogin(token, role);

      // 🔁 Redirect to correct dashboard
      switch (role) {
        case 'STUDENT':
          console.log("➡️ Redirecting to /student-dashboard");
          navigate('/student-dashboard');
          break;
        case 'COUNSELOR':
          console.log("➡️ Redirecting to /counselor-dashboard");
          navigate('/counselor-dashboard');
          break;
        case 'ADMIN':
          console.log("➡️ Redirecting to /admin-dashboard");
          navigate('/admin-dashboard');
          break;
        default:
          console.warn("🚫 Unknown role:", role);
          setError('Unknown user role. Please contact admin.');
          break;
      }
    } catch (error) {
      const errorMessage = error.response?.data || error.message || 'Unknown error';
      console.error("❌ Login error:", errorMessage);
      setError(`❌ Login failed: ${errorMessage}`);
    }
  };

  return (
    <div className="container mt-4" style={{ maxWidth: '400px' }}>
      <h3 className="text-center mb-4">Login</h3>
      <form onSubmit={handleLogin}>
        <div className="mb-3">
          <label className="form-label">Username:</label>
          <input
            type="text"
            className="form-control"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password:</label>
          <input
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary w-100">
          Login
        </button>
        {error && <p className="text-danger text-center mt-3">{error}</p>}
      </form>
    </div>
  );
}

export default LoginComponent;

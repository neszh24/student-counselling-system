import React, { useEffect, useState } from 'react';
import { getAppointmentsForCounselor } from '../services/AppointmentService';
import { getUserDetails } from '../services/TokenUtils';

const ViewAppointmentsForCounselor = () => {
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState(null);
  const user = getUserDetails();

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        if (!user?.id) {
          setError('Counselor ID not found');
          return;
        }

        const response = await getAppointmentsForCounselor(user.id);
        setAppointments(response.data);
      } catch (err) {
        console.error('❌ Failed to fetch appointments:', err);
        setError('Could not fetch appointments.');
      }
    };

    fetchAppointments();
  }, [user]);

  return (
    <div className="container mt-4">
      <h3>Your Appointments</h3>
      {error && <div className="alert alert-danger">{error}</div>}
      {appointments.length === 0 ? (
        <p>No appointments found.</p>
      ) : (
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Start</th>
              <th>End</th>
              <th>Status</th>
              <th>Notes</th>
              <th>Student ID</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map((appt) => (
              <tr key={appt.id}>
                <td>{appt.id}</td>
                <td>{appt.appointmentDate}</td>
                <td>{appt.startTime}</td>
                <td>{appt.endTime}</td>
                <td>{appt.status}</td>
                <td>{appt.notes}</td>
                <td>{appt.studentId}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ViewAppointmentsForCounselor;

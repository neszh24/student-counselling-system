import React, { useEffect, useState } from 'react';
import {
  createAppointment,
  checkSlotAvailability,
  getStudentByUsername
} from '../services/AppointmentService';
import { generateSlots } from '../services/SlotService';
import { getUserDetails } from '../services/TokenUtils';
import { generateICS } from './CalendarDownload.ics';
import EmailConfirmationModal from './EmailConfirmationModal';

function BookAppointmentComponent() {
  const [date, setDate] = useState('');
  const [counselorId, setCounselorId] = useState('');
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [status, setStatus] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [studentId, setStudentId] = useState(null);
  const [studentName, setStudentName] = useState('');  // Add studentName state
  const [notes, setNotes] = useState(''); // Notes field

  const slots = generateSlots();
  const user = getUserDetails();

  useEffect(() => {
    if (user && user.sub) {
      getStudentByUsername(user.sub)
        .then(res => {
          setStudentId(res.data.id);
          setStudentName(res.data.name);  // Assuming 'name' is part of the student data
        })
        .catch(err => {
          console.error('Failed to fetch student:', err);
          setStatus('⚠️ Unable to retrieve student details.');
        });
    }
  }, [user]);

  // Reset the form fields after the modal is closed
  const resetForm = () => {
    setDate('');
    setCounselorId('');
    setSelectedSlot(null);
    setNotes('');
  };

  // Check if the selected date is a weekend
  const isWeekend = (selectedDate) => {
    const day = new Date(selectedDate).getDay();
    return day === 6 || day === 0; // Saturday (6) and Sunday (0)
  };

  const handleBooking = async () => {
    if (!selectedSlot || !counselorId || !date || !studentId) {
      setStatus('⚠️ Please fill all fields and select a slot.');
      return;
    }

    if (isWeekend(date)) {
      setStatus('⚠️ You cannot book an appointment on weekends (Saturday/Sunday).');
      return;
    }

    const { startTime, endTime } = selectedSlot;

    try {
      const availability = await checkSlotAvailability(counselorId, date, startTime, endTime);
      if (!availability.data) {
        setStatus('❌ Slot not available.');
        return;
      }

      const appointment = {
        counselorId,
        studentId,
        appointmentDate: date,
        startTime,
        endTime,
        notes: notes.trim() !== '' ? notes : 'Session booked via portal' // Default fallback
      };

      await createAppointment(appointment);
      setStatus('✅ Appointment booked successfully!');
      setShowModal(true);

      generateICS({
        startTime,
        endTime,
        appointmentDate: date,
        counselorName: `Counselor ${counselorId}`
      });

    } catch (error) {
      console.error('❌ Booking failed:', error);
      setStatus('⚠️ Failed to book appointment. Please try again.');
    }
  };

  return (
    <div className="container mt-4">
      <h2>Book Appointment</h2>

      <div className="mb-3">
        <label>Counselor ID:</label>
        <select
          value={counselorId}
          onChange={(e) => setCounselorId(e.target.value)}
          className="form-control"
        >
          <option value="">Select Counselor</option>
          <option value="1">Counselor 1</option>
          <option value="2">Counselor 2</option>
        </select>
      </div>

      <div className="mb-3">
        <label>Date:</label>
        <input
          type="date"
          value={date}
          onChange={(e) => {
            const selectedDate = e.target.value;
            if (isWeekend(selectedDate)) {
              setStatus('⚠️ You cannot book an appointment on weekends (Saturday/Sunday).');
            } else {
              setStatus(''); // Clear status if valid date selected
            }
            setDate(selectedDate);
          }}
          className="form-control"
          min={new Date().toISOString().split('T')[0]} // Prevents past dates
        />
      </div>

      <div className="mb-3">
        <label>Available Slots:</label>
        <div className="d-flex flex-wrap">
          {slots.map((slot, index) => (
            <button
              key={index}
              className={`btn btn-sm ${
                selectedSlot?.startTime === slot.startTime && selectedSlot?.endTime === slot.endTime
                  ? 'btn-success'
                  : 'btn-outline-primary'
              } m-1`}
              onClick={() => setSelectedSlot(slot)}
            >
              {slot.startTime} - {slot.endTime}
            </button>
          ))}
        </div>
      </div>

      <div className="mb-3">
        <label>Session Notes:</label>
        <textarea
          className="form-control"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Add session notes (optional)"
        />
      </div>

      <button className="btn btn-primary" onClick={handleBooking}>Book Slot</button>
      {status && <p className="mt-3 text-info">{status}</p>}

      {/* Email Confirmation Modal */}
      <EmailConfirmationModal 
        show={showModal} 
        onClose={() => {
          setShowModal(false);
          resetForm(); // Reset the form after closing the modal
        }}
        studentName={studentName} // Pass student name to the modal
      />
    </div>
  );
}

export default BookAppointmentComponent;

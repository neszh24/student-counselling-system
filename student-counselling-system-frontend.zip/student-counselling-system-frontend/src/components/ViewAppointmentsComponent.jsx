// src/components/ViewAppointmentsComponent.jsx
import React, { useEffect, useState } from 'react';
import {
  getAppointmentsForStudent,
  getUpcomingAppointmentsForCounselor,
  getStudentByUsername
} from '../services/AppointmentService';
import { getUserDetails } from '../services/TokenUtils';

function ViewAppointmentsComponent() {
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState(null);
  const user = getUserDetails();

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        console.log('🔎 Current logged in user:', user);

        if (user.role === 'STUDENT') {
          console.log('🎓 Fetching student profile for:', user.sub);
          const studentRes = await getStudentByUsername(user.sub);

          console.log('✅ Student entity response:', studentRes.data);
          if (!studentRes.data || !studentRes.data.id) {
            console.error('❌ No student found or ID missing in response');
            setError('Student profile not found.');
            return;
          }

          const studentId = studentRes.data.id;
          console.log('📌 Using student ID:', studentId);

          const apptRes = await getAppointmentsForStudent(studentId);
          console.log('📅 Appointment response:', apptRes.data);
          setAppointments(apptRes.data);
        } else if (user.role === 'COUNSELOR') {
          const apptRes = await getUpcomingAppointmentsForCounselor(user.id);
          console.log('📅 Counselor appointments:', apptRes.data);
          setAppointments(apptRes.data);
        }
      } catch (err) {
        console.error('❌ Failed to fetch appointments:', err);
        setError('Could not fetch appointments.');
      }
    };

    fetchAppointments();
  }, [user]);

  return (
    <div className="container mt-4">
      <h3>Your Appointments</h3>
      {error && <div className="alert alert-danger">{error}</div>}
      {appointments.length === 0 ? (
        <p>No appointments to show.</p>
      ) : (
        <table className="table table-bordered table-hover">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Start</th>
              <th>End</th>
              <th>Status</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map((appt) => (
              <tr key={appt.id}>
                <td>{appt.id}</td>
                <td>{appt.appointmentDate}</td>
                <td>{appt.startTime}</td>
                <td>{appt.endTime}</td>
                <td>{appt.status}</td>
                <td>{appt.notes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default ViewAppointmentsComponent;

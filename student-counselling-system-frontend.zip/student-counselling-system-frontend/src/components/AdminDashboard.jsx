import React, { useEffect, useState } from 'react';
import axios from 'axios';

function AdminDashboard() {
  const [stats, setStats] = useState({
    students: 0,
    counselors: 0,
    admins: 0,
    totalAppointments: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      const usersRes = await axios.get('http://localhost:8080/api/users');
      const appointmentsRes = await axios.get('http://localhost:8080/api/appointments');

      const roleCounts = { STUDENT: 0, COUNSELOR: 0, ADMIN: 0 };
      usersRes.data.forEach((user) => {
        roleCounts[user.role] = (roleCounts[user.role] || 0) + 1;
      });

      setStats({
        students: roleCounts.STUDENT,
        counselors: roleCounts.COUNSELOR,
        admins: roleCounts.ADMIN,
        totalAppointments: appointmentsRes.data.length,
      });
    };

    fetchStats();
  }, []);

  return (
    <div className="container mt-5">
      <h2>Admin Dashboard</h2>
      <div className="row mt-4">
        <div className="col-md-3">
          <div className="card text-white bg-primary mb-3">
            <div className="card-header">Students</div>
            <div className="card-body">
              <h5 className="card-title">{stats.students}</h5>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-white bg-success mb-3">
            <div className="card-header">Counselors</div>
            <div className="card-body">
              <h5 className="card-title">{stats.counselors}</h5>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-white bg-dark mb-3">
            <div className="card-header">Admins</div>
            <div className="card-body">
              <h5 className="card-title">{stats.admins}</h5>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-white bg-info mb-3">
            <div className="card-header">Total Appointments</div>
            <div className="card-body">
              <h5 className="card-title">{stats.totalAppointments}</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;

import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

function PrivateRoute({ children, expectedRole }) {
  const { role, loading } = useContext(AuthContext);

  console.log("🔐 Access check: role=" + role + ", expected=" + expectedRole);

  if (loading) {
    console.log("⏳ Waiting for auth context to load...");
    return null;
  }

  if (role === expectedRole || (expectedRole === "STUDENT" && role === "COUNSELOR") || (expectedRole === "COUNSELOR" && role === "STUDENT")) {
    return children;
  }

  console.log("🚫 Access denied: expected '" + expectedRole + "', got '" + role + "'");
  return <Navigate to="/" replace />;
}

export default PrivateRoute;

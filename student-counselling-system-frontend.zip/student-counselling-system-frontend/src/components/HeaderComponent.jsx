import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getUserRole, getUserDetails, getToken } from '../services/TokenUtils';
import AuthService from '../services/AuthService';

function HeaderComponent() {
  const navigate = useNavigate();
  const role = getUserRole();
  const username = getUserDetails()?.sub || 'User';
  const isLoggedIn = !!getToken();

  const handleLogout = () => {
    AuthService.logout();
    navigate('/');
  };

  return (
    <header>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary px-4">
        <Link className="navbar-brand" to="/">
          🎓 Counselling Portal
        </Link>
        <div className="collapse navbar-collapse show">
          {isLoggedIn && (
            <ul className="navbar-nav me-auto">
              {role === 'STUDENT' && (
                <>
                  <li className="nav-item">
                    <Link className="nav-link" to="/student-dashboard">Dashboard</Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/book">Book Slot</Link>
                  </li>
                </>
              )}
              {role === 'COUNSELOR' && (
                <>
                  <li className="nav-item">
                    <Link className="nav-link" to="/counselor-dashboard">Appointments</Link>
                  </li>
                </>
              )}
              {role === 'ADMIN' && (
                <>
                  <li className="nav-item">
                    <Link className="nav-link" to="/admin-dashboard">Admin Panel</Link>
                  </li>
                </>
              )}
            </ul>
          )}
          <ul className="navbar-nav ms-auto">
            {isLoggedIn ? (
              <>
                <li className="nav-item">
                  <span className="navbar-text text-white me-3">Welcome, {username}</span>
                </li>
                <li className="nav-item">
                  <button className="btn btn-outline-light" onClick={handleLogout}>Logout</button>
                </li>
              </>
            ) : (
              <li className="nav-item">
                <Link className="btn btn-outline-light" to="/">Login</Link>
              </li>
            )}
          </ul>
        </div>
      </nav>
    </header>
  );
}

export default HeaderComponent;
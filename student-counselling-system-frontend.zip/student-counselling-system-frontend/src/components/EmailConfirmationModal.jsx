import React from 'react';
import { Modal, Button } from 'react-bootstrap';

function EmailConfirmationModal({ show, onClose, studentName }) {
  return (
    <Modal show={show} onHide={onClose}>
      <Modal.Header closeButton>
        <Modal.Title>Email Confirmation</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        Your appointment has been booked successfully for {studentName} and a confirmation email has been sent.
      </Modal.Body>
      <Modal.Footer>
        <Button variant="primary" onClick={onClose}>OK</Button>
      </Modal.Footer>
    </Modal>
  );
}

export default EmailConfirmationModal;

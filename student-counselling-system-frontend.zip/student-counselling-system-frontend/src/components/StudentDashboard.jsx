import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAppointmentsForStudent } from '../services/AppointmentService';
import { getUserDetails } from '../services/TokenUtils';

function StudentDashboard() {
  const [appointments, setAppointments] = useState([]);
  const [appointmentsThisWeek, setAppointmentsThisWeek] = useState(0); // New state to store the count
  const navigate = useNavigate();
  const student = getUserDetails();

  // Function to check if an appointment is within the current week
  const isThisWeekAppointment = (appointmentDate) => {
    const currentDate = new Date();
    const appDate = new Date(appointmentDate);

    // Clone currentDate to prevent mutation
    const startOfWeek = new Date(currentDate.getTime());
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());  // Sunday
    startOfWeek.setHours(0, 0, 0, 0);  // Set to start of the day

    const endOfWeek = new Date(startOfWeek.getTime());
    endOfWeek.setDate(startOfWeek.getDate() + 6); // Saturday
    endOfWeek.setHours(23, 59, 59, 999); // Set to end of the day

    const appDateObj = new Date(appointmentDate);
    return appDateObj >= startOfWeek && appDateObj <= endOfWeek; // Check if appointment is within this week
  };

  useEffect(() => {
    if (!student?.id) return;

    getAppointmentsForStudent(student.id)
      .then(response => {
        console.log('Fetched appointments:', response.data);
        const filteredAppointments = response.data.filter(appt => isThisWeekAppointment(appt.appointmentDate));
        console.log('Filtered appointments for this week:', filteredAppointments);
        setAppointments(filteredAppointments);
        setAppointmentsThisWeek(filteredAppointments.length); // Count appointments for this week
      })
      .catch(error => console.error('❌ Failed to fetch appointments:', error));
  }, [student?.id]);

  const handleBookClick = () => navigate('/book');
  const handleViewClick = () => navigate('/appointments');
  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    navigate('/');
  };

  return (
    <div className="container mt-4">
      <h2>Welcome, {student?.username || 'Student'}</h2>
      <div className="d-flex justify-content-between my-3">
        <button className="btn btn-primary" onClick={handleBookClick}>Book Appointment</button>
        <button className="btn btn-secondary" onClick={handleViewClick}>View Appointments</button>
        <button className="btn btn-danger" onClick={handleLogout}>Logout</button>
      </div>

      {/* <h4>Your Upcoming Appointments</h4>
      {appointmentsThisWeek === 0 ? (
        <p>No appointments this week.</p>
      ) : (
        <p>You have {appointmentsThisWeek} appointment(s) this week.</p>
      )} */}
    </div>
  );
}

export default StudentDashboard;

// src/components/CounselorDashboard.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getUserDetails } from '../services/TokenUtils';
import ViewAppointmentsForCounselor from './ViewAppointmentsForCounselor'; // Import the new component

function CounselorDashboard() {
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const user = getUserDetails();

  useEffect(() => {
    if (!user?.id) return;
    // You can do something with the user info here if needed.
  }, [user?.id]);

  const handleAppointmentsClick = () => {
    navigate('/appointments'); // Navigate to the ViewAppointmentsForCounselor page
  };

  return (
    <div className="container mt-4">
      <h2>Welcome, Counselor {user?.username}</h2>

      {error && <p className="text-danger">{error}</p>}

      {/* Add a button to navigate to appointments */}
      <button className="btn btn-primary my-3" onClick={handleAppointmentsClick}>
        View Appointments
      </button>

      {/* Displaying appointments for the counselor */}
      {user?.id && <ViewAppointmentsForCounselor />}
    </div>
  );
}

export default CounselorDashboard;

// Function to generate the correct .ics file with UTC times for Singapore timezone
export function generateICS(appointment) {
  const { startTime, endTime, appointmentDate, counselorName } = appointment;

  // Helper to pad numbers with leading 0s
  const pad = (n) => (n < 10 ? '0' + n : n);

  // Convert to UTC time format
  const convertToUTC = (dateStr, timeStr) => {
    const date = new Date(`${dateStr}T${timeStr}`);
    const utcDate = new Date(date.toUTCString()); // Convert local time to UTC
    return (
      utcDate.getUTCFullYear().toString() +
      pad(utcDate.getUTCMonth() + 1) +
      pad(utcDate.getUTCDate()) +
      'T' +
      pad(utcDate.getUTCHours()) +
      pad(utcDate.getUTCMinutes()) +
      pad(utcDate.getUTCSeconds()) +
      'Z' // Z indicates UTC
    );
  };

  const dtStart = convertToUTC(appointmentDate, startTime);
  const dtEnd = convertToUTC(appointmentDate, endTime);

  const icsContent = `
BEGIN:VCALENDAR
VERSION:2.0
CALSCALE:GREGORIAN
METHOD:PUBLISH
BEGIN:VEVENT
SUMMARY:Counselling Appointment with ${counselorName}
DTSTART:${dtStart}
DTEND:${dtEnd}
DTSTAMP:${dtStart}
DESCRIPTION:This is your scheduled student counselling session.
STATUS:CONFIRMED
SEQUENCE:0
BEGIN:VALARM
TRIGGER:-PT10M
DESCRIPTION:Reminder
ACTION:DISPLAY
END:VALARM
END:VEVENT
END:VCALENDAR`.trim();

  // Create and download ICS file
  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `counselling-${appointmentDate}.ics`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);

  URL.revokeObjectURL(url);
}

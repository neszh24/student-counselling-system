export const generateSlots = () => {
    const startHour = 9;
    const endHour = 17;
    const slotDuration = 1;
  
    const slots = [];
    for (let hour = startHour; hour < endHour; hour += slotDuration) {
      const startTime = `${hour.toString().padStart(2, '0')}:00`;
      const endTime = `${(hour + slotDuration).toString().padStart(2, '0')}:00`;
      slots.push({ startTime, endTime });
    }
    return slots;
  };
  
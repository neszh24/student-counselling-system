// src/services/AppointmentService.js

import axios from 'axios';
import { getToken } from './TokenUtils';

const API_URL = 'http://localhost:8080/api/appointments';

const authHeader = () => ({
  headers: {
    Authorization: `Bearer ${getToken()}`,
  },
});

// Fetch student entity by username
export const getStudentByUsername = (username) => {
  return axios.get(`http://localhost:8080/api/students/by-username/${username}`, authHeader());
};

// Create a new appointment
export const createAppointment = (appointmentData) => {
  return axios.post(`${API_URL}`, appointmentData, authHeader());
};

// Get all appointments for a student
export const getAppointmentsForStudent = (studentId) => {
  return axios.get(`${API_URL}/student/${studentId}`, authHeader());
};

// Get all appointments for a counselor
export const getAppointmentsForCounselor = (counselorId) => {
  return axios.get(`${API_URL}/counselor/${counselorId}`, authHeader());
};

// Get upcoming appointments for a counselor
export const getUpcomingAppointmentsForCounselor = (counselorId) => {
  return axios.get(`${API_URL}/counselor/${counselorId}/upcoming`, authHeader());
};

// Get past appointments for a counselor
export const getPastAppointmentsForCounselor = (counselorId) => {
  return axios.get(`${API_URL}/counselor/${counselorId}/past`, authHeader());
};

// Get a single appointment by ID
export const getAppointmentById = (id) => {
  return axios.get(`${API_URL}/${id}`, authHeader());
};

// Check if a slot is available
export const checkSlotAvailability = (counselorId, date, startTime, endTime) => {
  return axios.get(`${API_URL}/check-slot`, {
    headers: authHeader().headers,
    params: {
      counselorId,
      date,
      startTime,
      endTime,
    },
  });
};

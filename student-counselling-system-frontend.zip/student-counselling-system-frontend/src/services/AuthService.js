// src/services/AuthService.js
import axios from 'axios';

const API_URL = 'http://localhost:8080/api/auth';

const login = async (credentials) => {
  const response = await axios.post(`${API_URL}/login`, credentials);
  const { token, role } = response.data;

  // Store token and role
  localStorage.setItem('token', token);
  localStorage.setItem('role', role);

  return response;
};

const logout = () => {
  localStorage.clear();
};

const getToken = () => {
  return localStorage.getItem('token');
};

const getUserRole = () => {
  return localStorage.getItem('role');
};

const setUserRole = (role) => {
  localStorage.setItem('role', role);
};

// ✅ EXPORT ALL FUNCTIONS
const AuthService = {
  login,
  logout,
  getToken,
  getUserRole,
  setUserRole
};

export default AuthService;

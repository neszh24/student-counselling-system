// src/services/TokenUtils.js

// Get the JWT token from localStorage
export function getToken() {
  return localStorage.getItem('token');
}

// Save the token to localStorage
export function setToken(token) {
  localStorage.setItem('token', token);
}

// Clear the token on logout
export function clearToken() {
  localStorage.removeItem('token');
  localStorage.removeItem('role');
}

// Save the user role separately
export function setUserRole(role) {
  localStorage.setItem('role', role);
}

// Extract just the role from localStorage
export function getUserRole() {
  return localStorage.getItem('role');
}

// Decode user details from the token (e.g., ID, username)
export function getUserDetails() {
  const token = getToken();
  if (!token) return null;

  try {
    const payload = token.split('.')[1];
    const decoded = JSON.parse(atob(payload));
    const role = getUserRole(); // Attach role manually
    return { ...decoded, role };
  } catch (error) {
    console.error('Failed to decode token:', error);
    return null;
  }
}

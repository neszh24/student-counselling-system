// src/App.jsx
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import LoginComponent from './components/LoginComponent';
import StudentDashboard from './components/StudentDashboard';
import CounselorDashboard from './components/CounselorDashboard';
import AdminDashboard from './components/AdminDashboard';
import BookAppointmentComponent from './components/BookAppointmentComponent';
import ViewAppointmentsComponent from './components/ViewAppointmentsComponent';
import PrivateRoute from './components/PrivateRoute';

function App() {
  return (
    <>
      <HeaderComponent />
      <div className="container mt-3">
        <Routes>
          <Route path="/" element={<LoginComponent />} />
          <Route
            path="/student-dashboard"
            element={
              <PrivateRoute expectedRole="STUDENT">
                <StudentDashboard />
              </PrivateRoute>
            }
          />
          <Route
            path="/counselor-dashboard"
            element={
              <PrivateRoute expectedRole="COUNSELOR">
                <CounselorDashboard />
              </PrivateRoute>
            }
          />
          <Route
            path="/admin-dashboard"
            element={
              <PrivateRoute expectedRole="ADMIN">
                <AdminDashboard />
              </PrivateRoute>
            }
          />
          <Route
            path="/book"
            element={
              <PrivateRoute expectedRole="STUDENT">
                <BookAppointmentComponent />
              </PrivateRoute>
            }
          />
          <Route
            path="/appointments"
            element={
              <PrivateRoute expectedRole="STUDENT">
                <ViewAppointmentsComponent />
              </PrivateRoute>
            }
          />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
      <FooterComponent />
    </>
  );
}

export default App;

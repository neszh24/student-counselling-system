// src/context/AuthContext.jsx
import React, { createContext, useEffect, useState } from 'react';
import * as TokenUtils from '../services/TokenUtils';

const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true); // Prevent race condition during initial load

  useEffect(() => {
    const storedToken = TokenUtils.getToken();
    const storedRole = TokenUtils.getUserRole();
    if (storedToken && storedRole) {
      setRole(storedRole);
    }
    setLoading(false);
  }, []);

  const login = (token, role) => {
    TokenUtils.setToken(token);
    TokenUtils.setUserRole(role);
    setRole(role);
  };

  const logout = () => {
    TokenUtils.clearToken();
    setRole(null);
  };

  return (
    <AuthContext.Provider value={{ role, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

// ✅ Export both AuthContext and AuthProvider
export { AuthContext, AuthProvider };

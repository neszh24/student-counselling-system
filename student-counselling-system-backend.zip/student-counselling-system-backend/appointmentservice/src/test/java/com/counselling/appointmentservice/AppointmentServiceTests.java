package com.counselling.appointmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentServiceTests {

    @Test
    void testCreateAppointment() {
        // TODO: Add unit test logic
    }

    @Test
    void testSlotAvailability() {
        // TODO: Add unit test logic
    }
}

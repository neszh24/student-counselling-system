package com.counselling.appointmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationControllerTests {

    @Test
    void testRegister() {
        // TODO: Add mock test logic
    }

    @Test
    void testLogin() {
        // TODO: Add mock test logic
    }
}

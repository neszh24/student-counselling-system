package com.counselling.appointmentservice.service;

import com.counselling.appointmentservice.dto.AppointmentRequestDTO;
import com.counselling.appointmentservice.dto.AppointmentResponseDTO;
import com.counselling.appointmentservice.entity.Appointment;
import com.counselling.appointmentservice.entity.Counselor;
import com.counselling.appointmentservice.entity.Student;
import com.counselling.appointmentservice.repository.AppointmentRepository;
import com.counselling.appointmentservice.repository.CounselorRepository;
import com.counselling.appointmentservice.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentServiceImpl implements AppointmentService {

    private final AppointmentRepository appointmentRepository;

    // For testing only – remove later
    @Autowired private CounselorRepository counselorRepository;
    @Autowired private StudentRepository studentRepository;

    @Override
    public AppointmentResponseDTO createAppointment(AppointmentRequestDTO dto) {
        // Slot availability check
        if (!isSlotAvailable(dto.getCounselorId(), dto.getAppointmentDate(), dto.getStartTime())) {
            throw new IllegalStateException("This time slot is fully booked. Please choose another slot.");
        }

        Counselor counselor = counselorRepository.findById(dto.getCounselorId())
                .orElseThrow(() -> new RuntimeException("Counselor not found"));

        Student student = studentRepository.findById(dto.getStudentId())
                .orElseThrow(() -> new RuntimeException("Student not found"));

        Appointment appointment = Appointment.builder()
                .appointmentDate(dto.getAppointmentDate())
                .startTime(dto.getStartTime())
                .endTime(dto.getEndTime())
                .notes(dto.getNotes())
                .status(Appointment.Status.PENDING)
                .student(student)
                .counselor(counselor)
                .build();

        return toDTO(appointmentRepository.save(appointment));
    }

    @Override
    public AppointmentResponseDTO getAppointmentById(Long id) {
        return appointmentRepository.findById(id)
                .map(this::toDTO)
                .orElse(null);
    }

    @Override
    public List<AppointmentResponseDTO> getAppointmentsByCounselorAndDate(Long counselorId, LocalDate date) {
        return appointmentRepository
                .findByCounselorIdAndAppointmentDate(counselorId, date)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AppointmentResponseDTO> getAppointmentsByStudentId(Long studentId) {
        return appointmentRepository.findByStudentId(studentId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public boolean isSlotAvailable(Long counselorId, LocalDate date, LocalTime startTime) {
        List<Appointment> booked = appointmentRepository
                .findByCounselorIdAndAppointmentDateAndStartTime(counselorId, date, startTime);
        return booked.size() < 3;
    }

    @Override
    public List<AppointmentResponseDTO> getUpcomingAppointmentsForCounselor(Long counselorId) {
        return appointmentRepository
                .findByCounselorIdAndAppointmentDateAfterOrderByAppointmentDateAsc(counselorId, LocalDate.now())
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AppointmentResponseDTO> getPastAppointmentsForCounselor(Long counselorId) {
        return appointmentRepository
                .findByCounselorIdAndAppointmentDateBeforeOrderByAppointmentDateDesc(counselorId, LocalDate.now().plusDays(1))
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    // ✅ Helper: Converts Appointment entity → Response DTO
    private AppointmentResponseDTO toDTO(Appointment appointment) {
        AppointmentResponseDTO dto = new AppointmentResponseDTO();
        dto.setId(appointment.getId());
        dto.setAppointmentDate(appointment.getAppointmentDate());
        dto.setStartTime(appointment.getStartTime());
        dto.setEndTime(appointment.getEndTime());
        dto.setStatus(appointment.getStatus().name());
        dto.setNotes(appointment.getNotes());
        dto.setStudentName(appointment.getStudent().getFullName());
        dto.setCounselorName(appointment.getCounselor().getName());
        dto.setCounselorSpecialization(appointment.getCounselor().getSpecialization());
        return dto;
    }
}

package com.counselling.appointmentservice.entity;

public enum Role {
    STUDENT,
    COUNSELOR,
    ADMIN
}
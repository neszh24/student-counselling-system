package com.counselling.appointmentservice.repository;

import com.counselling.appointmentservice.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByCounselorIdAndAppointmentDate(Long counselorId, LocalDate date);

    List<Appointment> findByCounselorIdAndAppointmentDateAndStartTime(Long counselorId, LocalDate date, LocalTime startTime);

    List<Appointment> findByStudentId(Long studentId);

    List<Appointment> findByCounselorIdAndAppointmentDateAfterOrderByAppointmentDateAsc(Long counselorId, LocalDate date);

    List<Appointment> findByCounselorIdAndAppointmentDateBeforeOrderByAppointmentDateDesc(Long counselorId, LocalDate date);
}

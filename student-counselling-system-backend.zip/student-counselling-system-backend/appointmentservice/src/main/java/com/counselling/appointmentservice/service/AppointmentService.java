package com.counselling.appointmentservice.service;

import com.counselling.appointmentservice.dto.AppointmentRequestDTO;
import com.counselling.appointmentservice.dto.AppointmentResponseDTO;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface AppointmentService {
    AppointmentResponseDTO createAppointment(AppointmentRequestDTO dto);
    AppointmentResponseDTO getAppointmentById(Long id);
    List<AppointmentResponseDTO> getAppointmentsByCounselorAndDate(Long counselorId, LocalDate date);
    List<AppointmentResponseDTO> getAppointmentsByStudentId(Long studentId);
    boolean isSlotAvailable(Long counselorId, LocalDate date, LocalTime startTime);
    List<AppointmentResponseDTO> getUpcomingAppointmentsForCounselor(Long counselorId);
    List<AppointmentResponseDTO> getPastAppointmentsForCounselor(Long counselorId);
}

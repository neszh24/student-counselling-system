package com.counselling.appointmentservice.controller;

import com.counselling.appointmentservice.entity.Student;
import com.counselling.appointmentservice.repository.StudentRepository;
import com.counselling.appointmentservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentRepository studentRepository;
    private final UserRepository userRepository;

    @GetMapping("/by-username/{username}")
    public ResponseEntity<Student> getStudentByUsername(@PathVariable String username) {
        return userRepository.findByUsername(username)
                .flatMap(user -> studentRepository.findByUserId(user.getId()))
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}

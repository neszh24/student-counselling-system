package com.counselling.appointmentservice.repository;

import com.counselling.appointmentservice.entity.Counselor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CounselorRepository extends JpaRepository<Counselor, Long> {
}

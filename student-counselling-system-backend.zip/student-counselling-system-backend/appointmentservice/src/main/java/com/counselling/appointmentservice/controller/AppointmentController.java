package com.counselling.appointmentservice.controller;

import com.counselling.appointmentservice.dto.AppointmentRequestDTO;
import com.counselling.appointmentservice.dto.AppointmentResponseDTO;
import com.counselling.appointmentservice.service.AppointmentService;
import com.counselling.appointmentservice.service.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/appointments")
@RequiredArgsConstructor
public class AppointmentController {

    private final AppointmentService appointmentService;
    private final EmailService emailService;  // Inject EmailService

    /**
     * ✅ Create a new appointment
     */
    @PostMapping
    public ResponseEntity<AppointmentResponseDTO> createAppointment(@RequestBody AppointmentRequestDTO dto) {
        // Step 1: Create the appointment
        AppointmentResponseDTO created = appointmentService.createAppointment(dto);

        // Step 2: Prepare the email body for counselor
        String counselorEmailBody = "Dear Counselor,\n\n" +
                "You have a new counseling appointment booked.\n\n" +
                "Appointment Details: \n" +
                "Counselor ID: " + dto.getCounselorId() + "\n" +
                "Student ID: " + dto.getStudentId() + "\n" +
                "Date: " + dto.getAppointmentDate() + "\n" +
                "Start Time: " + dto.getStartTime() + "\n" +
                "End Time: " + dto.getEndTime() + "\n\n" +
                "Please check your schedule for more details.";

        // Step 3: Send email to the counselor (async to not block appointment creation)
        CompletableFuture.runAsync(() -> {
            try {
                String counselorEmail = "thinesh001@e.ntu.edu.sg"; // Hardcoded email for counselor
                emailService.sendEmail(counselorEmail, "New Appointment Booked", counselorEmailBody);
            } catch (Exception e) {
                System.err.println("❌ Failed to send email to counselor: " + e.getMessage());
            }
        });

        // Step 4: Prepare the email body for student
        String studentEmailBody = "Dear Student,\n\n" +
                "We are pleased to share that a new appointment has been booked for you.\n\n" +
                "Appointment Details: \n" +
                "Student ID: " + dto.getStudentId() + "\n" +
                "Counselor ID: " + dto.getCounselorId() + "\n" +
                "Date: " + dto.getAppointmentDate() + "\n" +
                "Start Time: " + dto.getStartTime() + "\n" +
                "End Time: " + dto.getEndTime() + "\n\n" +
                "We look forward to assisting you in your counseling session.";

        // Step 5: Send email to student (async to not block appointment creation)
        CompletableFuture.runAsync(() -> {
            try {
                String studentEmail = "thinesh001@e.ntu.edu.sg"; // Hardcoded email for student
                emailService.sendEmail(studentEmail, "Appointment Confirmation", studentEmailBody);
            } catch (Exception e) {
                System.err.println("❌ Failed to send email to student: " + e.getMessage());
            }
        });

        // Step 6: Return the response
        return ResponseEntity.ok(created);
    }

    /**
     * ✅ Get a single appointment by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<AppointmentResponseDTO> getAppointmentById(@PathVariable Long id) {
        AppointmentResponseDTO appointment = appointmentService.getAppointmentById(id);
        return appointment != null ? ResponseEntity.ok(appointment) : ResponseEntity.notFound().build();
    }

    /**
     * ✅ Get all appointments for a student
     */
    @GetMapping("/student/{id}")
    public ResponseEntity<List<AppointmentResponseDTO>> getAppointmentsForStudent(@PathVariable("id") Long studentId) {
        return ResponseEntity.ok(appointmentService.getAppointmentsByStudentId(studentId));
    }

    /**
     * ✅ Check if a slot is available for a given counselor, date, and start time
     */
    @GetMapping("/check-slot")
    public ResponseEntity<Boolean> checkSlotAvailability(
            @RequestParam("counselorId") Long counselorId,
            @RequestParam("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam("startTime") @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime startTime) {

        boolean available = appointmentService.isSlotAvailable(counselorId, date, startTime);
        return ResponseEntity.ok(available);
    }

    // Other methods (unchanged)
}

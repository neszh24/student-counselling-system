package com.counselling.appointmentservice;

import com.counselling.appointmentservice.entity.Counselor;
import com.counselling.appointmentservice.entity.Student;
import com.counselling.appointmentservice.entity.User;

import com.counselling.appointmentservice.repository.CounselorRepository;
import com.counselling.appointmentservice.repository.StudentRepository;
import com.counselling.appointmentservice.repository.UserRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class AppointmentserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppointmentserviceApplication.class, args);
	}

	@Bean
	public CommandLineRunner loadData(UserRepository userRepository,
									  StudentRepository studentRepository,
									  CounselorRepository counselorRepository) {
		return args -> {
			if (userRepository.count() == 0) {

				// Create User for Student
				User studentUser = new User();
				studentUser.setUsername("student1");
				studentUser.setPassword("pass123");
				studentUser.setRole(User.Role.STUDENT);
				userRepository.save(studentUser);

				// Create User for Counselor
				User counselorUser = new User();
				counselorUser.setUsername("counselor1");
				counselorUser.setPassword("pass456");
				counselorUser.setRole(User.Role.COUNSELOR);
				userRepository.save(counselorUser);

				// Create Student linked to studentUser
				Student student = new Student();
				student.setFullName("Jane Student");
				student.setEmail("jane@student.com");
				student.setDepartment("Computer Science");
				student.setUser(studentUser);
				studentRepository.save(student);

				// Create Counselor linked to counselorUser
				Counselor counselor = new Counselor();
				counselor.setName("Dr. John Counselor");
				counselor.setEmail("john@counsel.com");
				counselor.setSpecialization("Stress Management");
				counselor.setUser(counselorUser);
				counselorRepository.save(counselor);

				System.out.println("✅ Sample student and counselor created.");
			} else {
				System.out.println("ℹ️ Sample data already exists, skipping insert.");
			}
		};
	}
}
